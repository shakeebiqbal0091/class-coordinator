---
name: start-and-end-a-run
description: For the Class Coordinator of Class 7B only. Starts, ends or stops a run in the Log tab of the work record. Use it when a task file says to use this skill.
---

# Start and end a run

Owner: Ms. Ayesha Khan, class teacher of Class 7B.
Status: Draft, not tested. When the four tests pass, change this line to "Tested on YYYY-MM-DD".
Every name in this file is invented.

This skill holds steps only. The rules are in section 5 of the project instructions, "The work record: the Log tab". Each step points to that section. The task instructions file gives the task, the matter and the counts.

## First, check

Check that the project instructions have section 5, "The work record: the Log tab", and that you can open the Log tab of the Google Sheet named there. If one is missing, say which one, do nothing more, and stop.

## Start a run

S1. Note the start time, in the time zone that section 5 gives.

S2. Read the Log rows that the task file names: the rows of its matter, unless it names other rows.

S3. Add a Started row, as section 5 says: "<task> run <start time> started." If the task file gives more words for the Started row, add them after it.

S4. Look in the rows you read for an earlier run with a Started row and no Completed row. That run stopped, as section 5 says. Add no row for it.

S5. Go back to the task file. It says what is already done, and what may be half made.

## End a run

E1. Check that each item of this run has a Done row or a Needs Ms. Khan row. The task file says what an item is: a roll number, an email or the list. If an item has no such row, say which one in the report.

E2. Add a Completed row: "<task> run <start time> completed: <the counts the task file gives>." Take each count from the Log rows of this run, as section 5 says.

E3. Report each count, with the rows it came from, each item with no draft or no result, with the reason, and every tool you used.

## Stop a run

E4. Add a Needs Ms. Khan row with the reason, as section 7 says. Then add a Completed row: "<task> run <start time> completed: nothing more made, see row N." Report the reason.
