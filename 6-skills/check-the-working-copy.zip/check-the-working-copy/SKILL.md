---
name: check-the-working-copy
description: For the Class Coordinator of Class 7B only. Checks the working copy before a task reads a tab in it, first the Updated tab, then the headings. Use it when a task file says to use this skill.
---

# Check the working copy

Owner: Ms. Ayesha Khan, class teacher of Class 7B.
Status: Draft, not tested. When the four tests pass, change this line to "Tested on YYYY-MM-DD".
Every name in this file is invented.

This skill holds steps only. The rules are in sections 3 and 7 of the project instructions. Each step points to them. The task instructions file names the tab and its headings.

## First, check

Check that the project instructions have section 3, "Your sources", and that you can open the Updated tab of the working copy named there. If one is missing, say which one, do nothing more, and stop.

## Steps

C1. Read cell A2 of the Updated tab. Compare it with today, by the rule for the Updated tab in section 3: empty, more than seven days before today, or after today. If that rule says to stop, add the row it gives. If the task file says what to do then, do that. If not, make nothing, and stop the run.

C2. Read the tab that the task file names.

C3. Compare the first row of the tab with the headings the task file gives, one by one, in the same order. If they differ, end the run with a Needs Ms. Khan row that names the tab and each heading that differs, as section 7 says.

C4. Go back to the task file.
