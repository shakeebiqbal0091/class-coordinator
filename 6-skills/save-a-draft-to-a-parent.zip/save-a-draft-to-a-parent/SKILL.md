---
name: save-a-draft-to-a-parent
description: For the Class Coordinator of Class 7B only. Writes one email draft to a parent by roll number, saves it in Gmail, and adds its Done row. Use it when a task file says to use this skill.
---

# Save a draft to a parent

Owner: Ms. Ayesha Khan, class teacher of Class 7B.
Status: Draft, not tested. When the four tests pass, change this line to "Tested on YYYY-MM-DD".
Every name in this file is invented.

This skill holds steps only. The rules are in sections 4, 5 and 6 of the project instructions. Each step points to them. The task instructions file gives the draft and the words of the Done row.

## First, check

Check that the project instructions have sections 4, 5 and 6, that you can open the Students tab of the working copy, and that the task file has the draft to write (for example "## The draft"). If one is missing, say which one, do nothing more, and stop.

## Steps

D1. Find the parent email in the Students tab, by roll number, as section 4 says. If it is missing, draft nothing. Add a Needs Ms. Khan row: "No draft: no parent email". Tell Ms. Khan, and go to the next roll number.

D2. Write the draft that the task file gives, with any Check lines the task file gives. Write the name as section 4 says.

D3. Read the Log rows of the matter again, as section 5 says. If a Done row for this draft is there now, save nothing. If not, save it as a draft in Ms. Khan's Gmail, as section 6 says.

D4. Add a Done row: the roll number, the What happened words the task file gives, any Check line, and the Next the task file gives. Fill in Origin and Source as section 5 says. Write the row as section 5 says: the roll number, never the email address.

D5. Go back to the task file.
